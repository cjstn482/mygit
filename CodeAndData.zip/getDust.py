import csv
from datetime import datetime, timedelta

def getDustData(file_path, save_path, save_path2):

    with open(file_path, mode='r', encoding='cp949') as file:
        csv_reader = csv.reader(file)
        next(csv_reader)
        dateData='20200101' #시작 기간 정보를 저장
        sumOfNo2 =0.0
        sumOfO3=0.0
        sumOfCo=0.0
        sumOfSo2=0.0
        sumOfPm10= 0.0
        sumOfPm25 = 0.0
        queue = list() #데이터 저장용 큐

        rowCount = 0  # 기간 데이터 개수 확인
        for row in csv_reader:

            rowCount += 1 #서울시의 각 구마다 count 증가
            if row[0] == dateData:

                try:
                    sumOfNo2 += float(row[2]) #각 값들이 공백 입력 받는 예외 처리
                except ValueError:
                    continue
                try:
                    sumOfO3 += float(row[3])
                except ValueError:
                    continue
                try:
                    sumOfCo += float(row[4])
                except ValueError:
                    continue
                try:
                    sumOfSo2 += float(row[5])
                except ValueError:
                    continue
                try:
                    sumOfPm10 += float(row[6])
                except ValueError:
                    continue
                try:
                    sumOfPm25 += float(row[7])
                except ValueError:
                    continue

            else:

                sumOfNo2 /= rowCount # 서울특별시 내의 각 구의 대기오염 농도 합/ 각 구의 개수의 합
                sumOfO3 /= rowCount
                sumOfCo /= rowCount
                sumOfSo2 /= rowCount
                sumOfPm10 /= rowCount
                sumOfPm25 /= rowCount

                sumOfNo2 = round(sumOfNo2, 4) # 소수점 자리 반올림
                sumOfO3 = round(sumOfO3, 4)
                sumOfCo = round(sumOfCo, 2)
                sumOfSo2 = round(sumOfSo2, 6)
                sumOfPm10 = round(sumOfPm10, 2)
                sumOfPm25 = round(sumOfPm25, 2)


                writeDataSet = [ sumOfNo2, sumOfO3, sumOfCo, sumOfSo2 , sumOfPm10, sumOfPm25]
                queue.append(writeDataSet)
                rowCount = 0 #Count 초기화
                date_obj = datetime.strptime(dateData, '%Y%m%d')
                # 하루를 더하기
                new_date_obj = date_obj + timedelta(days=1)
                # 새로운 날짜를 문자열로 변환
                dateData = new_date_obj.strftime('%Y%m%d')

                sumOfNo2 = 0.0 # 각 대기오염 변수 저장값 초기화
                sumOfO3 = 0.0
                sumOfCo = 0.0
                sumOfSo2 = 0.0
                sumOfPm10 = 0
                sumOfPm25 = 0

    with open(save_path, mode='w',newline='', encoding='cp949') as file:
        writer = csv.writer(file)

        writer.writerow(['PM10', 'PM25']) # pm10, pm25 데이터 particulate_matter에 저장
        for row in queue:
            writer.writerow([row[4], row[5]])

    with open(save_path2, mode='w',newline='', encoding='cp949') as file:
        writer = csv.writer(file)

        writer.writerow(['NO2','O3','CO', 'SO2']) # NO2, O3, CO, SO2 air_pollution에 저장
        for row in queue:
            writer.writerow([row[0], row[1], row[2], row[3]])





    # with open(weather_save_path, mode='r',newline='', encoding='utf-8') as file:
    #     reader = csv.reader(file)
    #     next(reader)
    #     for row in reader:
    #         # row= rowData.split()
    #         print(row)
    #         if queue:
    #             popped = queue.pop(0)
    #         else:
    #             popped = [0,0,0,0]
    #
    #         queueData = [row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7],row[8], popped[0],popped[1],popped[2],popped[3]]
    #         queueW.append(queueData)
    #
    #
    # with open(weather_save_path, mode='w',newline='', encoding='cp949') as file:
    #     writer = csv.writer(file)
    #     writer.writerow(['YYMMDD', 'WSAVG','WD', 'WSMAX', 'TAAVG', 'TAMAX', 'TAMIN', 'HMAVG', 'RNDAY','NO2','O3','CO','SO2'])
    #     for row in queueW:
    #         writer.writerow(row)