import getDust
import weather
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import matplotlib.pyplot as plt
import seaborn as sns


# # weather.py에서 사용할 API 엔드포인트 URL
# url=''
# api_key = ""

# 파일 경로 설정
weather_file_path = './weather.csv' #
air_pollution_path = './air_pollution.csv'
particulate_matter_path = './particulate_matter.csv'

api_url = ''

# 날씨 데이터 다운로드
# weather.download_file(api_url, weather_file_path) #api call 대신 미리 api로 만든 data를 사용하고 함수는 미사용

# 대기오염 데이터 가공
dust_raw_file_path = './일별평균대기오염도4.csv'  # 2020년~2023년 대기오염 원본 파일
getDust.getDustData(dust_raw_file_path, particulate_matter_path,air_pollution_path) # 4년치 정보가 저장된 일별평균대기오염도4에서 대기오염도와 미세먼지 데이터를 분리해서 각각 air_pollution.csv와 particulate_matter.csv에 저장

weather_df = pd.read_csv('weather.csv') # 기상데이터
air_pollution_df = pd.read_csv('air_pollution.csv') # 대기오염 데이터 (NO2, O3, CO, SO2)
particulate_matter_df = pd.read_csv('particulate_matter.csv') # 미세먼지 데이터 (PM10, PM25)

print(weather_df.head())
print(air_pollution_df.head())
print(particulate_matter_df.head())

# 데이터 불러오기
weather_data = pd.read_csv(weather_file_path)
air_pollution_data = pd.read_csv(air_pollution_path)
particulate_matter_data = pd.read_csv(particulate_matter_path)
# 데이터 병합
data = pd.concat([weather_data, particulate_matter_data], axis=1)

# YYMMDD를 활용한 파생 변수 생성
data['Year'] = data['YYMMDD'] // 10000  # 연도 추출
data['Month'] = (data['YYMMDD'] // 100) % 100  # 월 추출
data['Day'] = data['YYMMDD'] % 100  # 일 추출

# 계절 변수 생성
def get_season(month):

    if month in [ 4, 5]:
        return 'Spring'
    elif month in [6, 7, 8, 9]:
        return 'Summer'
    elif month in [10 ,11]:
        return 'Autumn'
    else:
        return 'Winter'

data['Season'] = data['Month'].apply(get_season)

# 계절 변수를 원-핫 인코딩
data = pd.get_dummies(data, columns=['Season'], drop_first=True)

# 불필요한 열 제거
data = data.drop(columns=['YYMMDD']).dropna()
# data = data.drop(columns=['Year']).dropna()
data = data.drop(columns=['Month']).dropna()
data = data.drop(columns=['Day']).dropna()

# 2020~2022년을 훈련 데이터, 2023년을 테스트 데이터로 나누기
train_data = data[data['Year'].between(2020, 2022)]  # 2020~2022년 데이터
test_data = data[data['Year'] == 2023]  # 2023년 데이터

# 독립 변수(X)와 종속 변수(y) 설정
X_train = train_data.drop(columns=['PM10', 'PM25', 'Year'])
y_pm10_train = train_data['PM10']
y_pm25_train = train_data['PM25']

X_test = test_data.drop(columns=['PM10', 'PM25', 'Year'])
y_pm10_test = test_data['PM10']
y_pm25_test = test_data['PM25']

# 모델 학습
model_pm10 = RandomForestRegressor(
    n_estimators=2000,
    max_depth=50,
    min_samples_split=20,
    random_state=42
)
model_pm25 = RandomForestRegressor(
    n_estimators=750,
    max_depth=10,
    min_samples_split=5,
    random_state=42
)

model_pm10.fit(X_train, y_pm10_train)
model_pm25.fit(X_train, y_pm25_train)

# 예측
y_pm10_pred = model_pm10.predict(X_test)
y_pm25_pred = model_pm25.predict(X_test)

# 평가
print("PM10 예측 정확도:")
print("MAE:", mean_absolute_error(y_pm10_test, y_pm10_pred))
print("RMSE:", np.sqrt(mean_squared_error(y_pm10_test, y_pm10_pred)))
print("R2 Score:", r2_score(y_pm10_test, y_pm10_pred))

print("\nPM2.5 예측 정확도:")
print("MAE:", mean_absolute_error(y_pm25_test, y_pm25_pred))
print("RMSE:", np.sqrt(mean_squared_error(y_pm25_test, y_pm25_pred)))
print("R2 Score:", r2_score(y_pm25_test, y_pm25_pred))

# 시각화
plt.figure(figsize=(12, 6))
plt.plot(y_pm10_test.values, label='Actual PM10', marker='o')
plt.plot(y_pm10_pred, label='Predicted PM10', marker='x')
plt.title('Actual vs Predicted PM10')
plt.xlabel('Samples')
plt.ylabel('PM10 Level')
plt.legend()
plt.show()

plt.figure(figsize=(12, 6))
plt.plot(y_pm25_test.values, label='Actual PM2.5', marker='o')
plt.plot(y_pm25_pred, label='Predicted PM2.5', marker='x')
plt.title('Actual vs Predicted PM2.5')
plt.xlabel('Samples')
plt.ylabel('PM2.5 Level')
plt.legend()
plt.show()

# Feature Importance
importance_pm10 = model_pm10.feature_importances_
importance_pm25 = model_pm25.feature_importances_

feature_importance_pm10 = pd.Series(importance_pm10, index=X_train.columns).sort_values(ascending=False)
feature_importance_pm25 = pd.Series(importance_pm25, index=X_train.columns).sort_values(ascending=False)

# Feature Importance 시각화
plt.figure(figsize=(14, 6))
plt.subplot(1, 2, 1)
feature_importance_pm10.plot(kind='bar')
plt.title('Feature Importance for PM10')

plt.subplot(1, 2, 2)
feature_importance_pm25.plot(kind='bar')
plt.title('Feature Importance for PM25')
plt.show()

# 상관관계 분석
correlation_matrix = data.drop(columns=['Year']).corr()

# 상관관계 분석 결과 시각화
plt.figure(figsize=(14, 10))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt='.2f')
plt.title('Correlation Matrix Between Features and Targets (Excluding Year)')
plt.show()

#==================================================================================================================================================================#
#==================================================================================================================================================================#
#==================================================================================================================================================================#

# 데이터 병합
data = pd.concat([air_pollution_data, particulate_matter_data], axis=1)

# 독립 변수(X)와 종속 변수(y) 설정
X = data.drop(columns=['PM10', 'PM25'])
y_pm10 = data['PM10']
y_pm25 = data['PM25']

# 데이터 분할
X_train, X_test, y_pm10_train, y_pm10_test = train_test_split(X, y_pm10, test_size=0.2, random_state=42)
X_train, X_test, y_pm25_train, y_pm25_test = train_test_split(X, y_pm25, test_size=0.2, random_state=42)


# 모델 학습
model_pm10 = RandomForestRegressor(
    n_estimators=2000,
    max_depth=50,
    min_samples_split=20,
    random_state=42
)
model_pm25 = RandomForestRegressor(
    n_estimators=750,
    max_depth=10,
    min_samples_split=5,
    random_state=42
)

model_pm10.fit(X_train, y_pm10_train)
model_pm25.fit(X_train, y_pm25_train)

# 예측
y_pm10_pred = model_pm10.predict(X_test)
y_pm25_pred = model_pm25.predict(X_test)

# 평가
print("PM10 예측 정확도:")
print("MAE:", mean_absolute_error(y_pm10_test, y_pm10_pred))
print("RMSE:", np.sqrt(mean_squared_error(y_pm10_test, y_pm10_pred)))
print("R2 Score:", r2_score(y_pm10_test, y_pm10_pred))

print("\nPM2.5 예측 정확도:")
print("MAE:", mean_absolute_error(y_pm25_test, y_pm25_pred))
print("RMSE:", np.sqrt(mean_squared_error(y_pm25_test, y_pm25_pred)))
print("R2 Score:", r2_score(y_pm25_test, y_pm25_pred))

# 시각화
plt.figure(figsize=(12, 6))
plt.plot(y_pm10_test.values, label='Actual PM10', marker='o')
plt.plot(y_pm10_pred, label='Predicted PM10', marker='x')
plt.title('Actual vs Predicted PM10')
plt.xlabel('Samples')
plt.ylabel('PM10 Level')
plt.legend()
plt.show()

plt.figure(figsize=(12, 6))
plt.plot(y_pm25_test.values, label='Actual PM2.5', marker='o')
plt.plot(y_pm25_pred, label='Predicted PM2.5', marker='x')
plt.title('Actual vs Predicted PM2.5')
plt.xlabel('Samples')
plt.ylabel('PM2.5 Level')
plt.legend()
plt.show()

# Feature Importance
importance_pm10 = model_pm10.feature_importances_
importance_pm25 = model_pm25.feature_importances_

feature_importance_pm10 = pd.Series(importance_pm10, index=X_train.columns).sort_values(ascending=False)
feature_importance_pm25 = pd.Series(importance_pm25, index=X_train.columns).sort_values(ascending=False)

# Feature Importance 시각화
plt.figure(figsize=(14, 6))
plt.subplot(1, 2, 1)
feature_importance_pm10.plot(kind='bar')
plt.title('Feature Importance for PM10')

plt.subplot(1, 2, 2)
feature_importance_pm25.plot(kind='bar')
plt.title('Feature Importance for PM25')
plt.show()

# 상관관계 분석
correlation_matrix = data.corr()

# 상관관계 분석 결과 시각화
plt.figure(figsize=(8, 6))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt='.2f')
plt.title('Correlation Matrix Between Features and Targets (Excluding Year)')
plt.show()
