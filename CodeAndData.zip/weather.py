import requests
import csv


def download_file(file_url, save_path):
    # URL에서 파일을 다운로드
    response = requests.get(file_url)

    # 응답 내용이 CSV 형식인지 확인
    if response.status_code == 200:
        response.encoding = 'cp949'
        print(f'encoding: {response.encoding}')

        # 응답 내용을 텍스트로 디코딩
        try:
            decoded_content = response.text  # response.text는 자동으로 인코딩을 처리한 텍스트
        except UnicodeDecodeError:
            print("디코딩 오류 발생. 다른 인코딩 시도 중...")
            decoded_content = response.content.decode('ISO-8859-1')  # ISO-8859-1로 시도
            print("ISO-8859-1로 디코딩됨.")

        # CSV 데이터를 읽기 위한 텍스트로 변환
        csv_lines = decoded_content.splitlines()


        # CSV 파일로 저장
        with open(save_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            for line in csv_lines:

                if len(line.split()) > 1 and line.split()[1].strip() == 'YYMMDD':
                    data = line.split()
                    dataNew = [data[1], 'WSAVG','WD', 'WSMAX', 'TAAVG', 'TAMAX', 'TAMIN', 'HMAVG', 'RNDAY']

                    writer.writerow(dataNew)
                elif len(line.split()) == 1 or line.split()[0] == "#":
                    continue
                else:
                    data = line.split()
                    rnData = 0.0

                    # 강수량값이 이상치로 음수가 나오는게 많아서 음수로 나온 강수값들을 처리하는 부분
                    try:
                        # 강수량 값을 숫자로 변환
                        rnData = float(data[38])

                        # 강수량이 음수인 경우 0으로 수정
                        if rnData < 0:
                            rnData = 0.0

                    except (ValueError, IndexError):  # ValueError와 IndexError를 모두 처리
                        # 숫자가 아닌 경우나 값이 없는 경우 (빈공백 등)
                        rnData = 0.0

                    # 새로운 데이터로 준비
                    dataNew = [data[0], data[2], data[4], data[5], data[10], data[11], data[13], data[18], rnData]
                    # data[0] = YYMMDD, data[2] = WSAVG, data[4] = WD , data[5] = WSMAX, data[10] = TAAVG..... data[18] = HMAVG, rnData = RNDAY

                    # 파일에 기록
                    writer.writerow(dataNew)

        print(f"파일이 {save_path}로 저장되었습니다.")
    else:
        print(f"파일 다운로드 실패: {response.status_code}")